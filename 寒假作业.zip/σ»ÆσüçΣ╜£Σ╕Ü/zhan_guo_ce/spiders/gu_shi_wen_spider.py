import scrapy
import os
import json

from scrapy import Request
from zhan_guo_ce.items import *
from urllib.parse import urlparse
from zhan_guo_ce.pipelines import ZhanGuoCePipeline


class DmozSpider(scrapy.spiders.Spider):
    name = "zhanguoce"
    allowed_domains = ["gushiwen.org", "dangdang.com"]
    start_urls = [
        "https://so.gushiwen.org/guwen",
    ]

    domain = "https://so.gushiwen.org"



    def parse(self, response):
        sel = response.xpath("//div[@class='main3']//div[@class='son2']")

        for item in sel:
            class_name = item.xpath("div[@class='sleft']/a/text()").extract()[0]

            category_name = item.xpath("div[@class='sright']//a/text()").extract()
            category_ref = item.xpath("div[@class='sright']//a/@href").extract()


            for x in range(0,len(category_name)):


                # 这里 需要截取一下url，因为直接拼接导致路径重复了
                url ="{0}{1}".format(response.url[:-7], category_ref[x])
                category = "{0}/{1}".format(class_name, category_name[x])



                yield Request(url=url, callback=self.bookCategoryParse, meta={"category": category, "path": response.url})





    def bookCategoryParse(self, response):


        for sel in response.xpath("//div[@class='main3']//div[@class='sonspic']/div[1]"):

            path = sel.xpath("p[1]/a[1]/@href").extract()[0]
            name = sel.xpath("p[1]/a[1]/b/text()").extract()[0]
            desc = sel.xpath("p[2]/text()").extract()[0]


            domain = urlparse(response.url).netloc
            url = "https://{0}{1}".format(domain,path)

            meta = response.meta
            meta["title"] = name
            meta["desc"] = desc
            meta["path"] = meta["path"] + "=>" + response.url



            bookinfo = BookInfo()
            bookinfo["title"] = name
            bookinfo["desc"] = desc
            bookinfo["category"] = response.meta["category"]

            request = Request(url=url, callback=self.bookIndexParse, meta=meta)
            bookinfo["request"] = request

            ZhanGuoCePipeline().process_item(bookinfo,self)




            yield Request(url=url, callback=self.bookIndexParse, meta=meta)
          #  return Request(url=url, callback=self.bookIndexParse, meta=meta)

# 分章节的书籍解析
    def bookIndexParse(self,response):
        requestList = []


        for sel in response.xpath("//div[@class='bookcont']"):
            sections = sel.xpath("div[1]/strong/text()").extract()
            article_path = sel.xpath("div[2]//span/a/@href").extract()
            article_name = sel.xpath("div[2]//span/a/text()").extract()
            print("bookIndexParse result")
            print(sections)

            if len(sections) == 0 or sections is None:
                print("没有分卷，直接解析")
                requestList = requestList + self.bookIndexParse2(response)




            for x in range(0,len(article_path)):
                url = self.domain + article_path[x]
                meta = response.meta
                meta["section"] = sections[0]
                meta["path"] = meta["path"] + "=>" + response.url

                requestList.append(Request(url=url,callback=self.bookDetailParse,meta=meta))
        return requestList


# 不分章节的书籍，解析
    def bookIndexParse2(self, response):
        requestList = []

        for sel in response.xpath("//div[@class='bookcont']/ul/span/a"):
            article_path = sel.xpath("@href").extract()[0]
            article_name = sel.xpath("text()").extract()[0]

            meta = response.meta
            meta["path"] = meta["path"] + "=>" + response.url

            url = self.domain + article_path

            requestList.append(Request(url=url, callback=self.bookDetailParse, meta=meta))
        return requestList



    def bookDetailParse(self,response):

        # print(response.meta)
        meta = response.meta
        meta["path"] = meta["path"] + "=>" + response.url



        title = response.xpath("//div[@class='cont']/h1/span/b/text()").extract()[0]

        contents = response.xpath("//div[@class='cont']/div[@class='contson']//p/text()").extract()

        if len(contents) == 0:
            contents = response.xpath("//div[@class='cont']/div[@class='contson']/text()").extract()


        content = "\n".join(contents)

        category = response.meta["category"]

        article = Article()
        article["title"] = title
        article["content"] = content
        article["category"] = category
        article["bookname"] = meta["title"]
        if "section" in response.meta:
            article["section"] = response.meta["section"]
        else:
            article["section"] = None

        return article











