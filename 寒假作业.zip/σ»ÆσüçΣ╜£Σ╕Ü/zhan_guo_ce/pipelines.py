# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

from zhan_guo_ce.items import *
import os
import json


class ZhanGuoCePipeline(object):
    def process_item(self, item, spider):
        if type(item) is Article:
            self.writeArticle(item)
        elif type(item) is BookInfo:
            self.writeBookInfo(item)
            return item["request"]


     #   return item

    def writeArticle(self, article):
        if article["section"] is None:
            path = article["category"] + '/' + article["bookname"]
            print("该书不分卷:", article["bookname"] )
        else:

            path = article["category"] + '/' + article["bookname"] + '/' + article["section"]

        if not os.path.exists(path):
            os.makedirs(path)


        file = path + '/' + article["title"] + '.json'




        context = {"title": article["title"], "content": article["content"]}




        with open(file, 'w', encoding='utf-8') as f:
             json.dump(context, f, ensure_ascii=False, indent=4)
             f.close()

    def writeBookInfo(self, bookInfo):


        path = bookInfo["category"] + '/' + bookInfo["title"]


        if not os.path.exists(path):
            os.makedirs(path)

        file = path + '/' + 'info.json'

        context = {"title": bookInfo["title"], "desc": bookInfo["desc"]}


        with open(file, 'w', encoding='utf-8') as f:
             json.dump(context, f, ensure_ascii=False, indent=4)
             f.close()
