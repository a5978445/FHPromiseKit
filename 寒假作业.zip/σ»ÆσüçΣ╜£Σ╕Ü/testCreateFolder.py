import os
import json
import jieba
import jieba.posseg as pseg

path="/Users/litengfang/Desktop/zhan_guo_ce/集部：/别集类/曾国藩家书/"


def findJsonFile():
    for dirpath, dirnames, filenames in os.walk(path):
        print(dirpath)
        print(filenames)
        for file in filenames:
            if file.endswith(".json"):
                print(file)
                yield dirpath + '/' + file

seg_list = []
# for file in findJsonFile():
#
#     articleDictionary = json.load(open(file,'r'))
#
#     if "content" in articleDictionary:
#         #print(articleDictionary["content"])
#         seg_list.append(" ".join(jieba.cut(articleDictionary["content"], cut_all=False)))
#
#
# result_str = " ".join(seg_list)
# object_file = open("/Users/litengfang/Desktop/fenci.txt",'w')
# object_file.write(result_str)

jieba.load_userdict("/Users/litengfang/Desktop/zengguofan_cixing.txt")
lists = []
for file in findJsonFile():

    articleDictionary = json.load(open(file,'r'))


    if "content" in articleDictionary:
        #print(articleDictionary["content"])
        words = pseg.cut(articleDictionary["content"],use_paddle=False) #paddle模式

        for word, flag in words:
        #     print('%s %s' % (word, flag))
             if flag == "nr":
                 lists.append(word)


flag_file = open("/Users/litengfang/Desktop/flag.txt",'w')
flag_file.write(" ".join(lists))




# if not os.path.exists(path):
#    os.makedirs(path)
#
#
# text = """
# faguiopsdlkfjksashdhasdhaljsdjasdasjdasdjasdhasjdjasjd
# hello world!
# hhhhhhhh
# """
# print(text)
#
#
#
# dic = {
# "name": "fitch",
# "age": "18"
# }
#
# jsObj = json.dumps(dic)
#
# file = path +'/' + 'jsonFile.json'
#
# fileObject = open(file, 'w')
# fileObject.write(jsObj)
# fileObject.close()
